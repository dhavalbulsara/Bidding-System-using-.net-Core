/*Dhaval Bulsara (1032083)*/

/* Display which user bought which property with Amount */

SELECT B.SOLDDATE, A.ADDRESS, B.AMOUNT, CONCAT(C.FNAME, ' ', C.LNAME) AS BUYER FROM PROPERTYMASTER A INNER JOIN SOLDMASTER B INNER JOIN USERMASTER C ON A.ID=B.PROPERTYID AND B.USER_ID=C.ID WHERE A.STATUS='SOLD' order by buyer;
/*+---------------------+-------------------+--------+-------------+
| SOLDDATE            | ADDRESS           | AMOUNT | BUYER       |
+---------------------+-------------------+--------+-------------+
| 2018-04-06 21:35:53 | 433, PARK AVENUE  |  40000 | AVI PATEL   |
| 2018-04-06 21:35:53 | 43, WALNUT STREET | 100000 | AVI PATEL   |
| 2018-04-06 21:35:53 | 2, RENNELL STREET | 100000 | SUNIL DUDHE |
+---------------------+-------------------+--------+-------------+*/


/* Display number of properties that are sold  by users*/

select b.fname,count(a.id) from propertymaster a inner join usermaster b on a.user_id=b.id where a.status='SOLD' group by b.fname ;
/*+----------+-------------+
| fname    | count(a.id) |
+----------+-------------+
| ADITYA   |           1 |
| ABHI     |           1 |
| KRUTARTH |           1 |
+----------+-------------+*/

/* List of all user who have listed more than one property*/

select b.fname from propertymaster a inner join usermaster b on a.user_id=b.id  group by b.fname having count(a.user_id)>1 ;
/*+----------+
| fname    |
+----------+
| ADITYA   |
| KRUTARTH |
| ABHI     |
+----------+*/

/* List of all user who have logged out*/

SELECT A.TYPE, CONCAT(A.FNAME, ' ', A.LNAME) AS NAME, 
B.USERNAME, B.PASSWORD,  A.SEX, A.EMAIL, A.PHONE  
FROM USERMASTER A INNER JOIN USERLOGIN B 
ON A.ID = B.USER_ID where a.id in (select c.user_id from userloginlog c where c.action='LOGOUT');

/*+--------+-----------------+----------------+----------+-----+--------------------------+------------+
| TYPE   | NAME            | USERNAME       | PASSWORD | SEX | EMAIL                    | PHONE      |
+--------+-----------------+----------------+----------+-----+--------------------------+------------+
| CLIENT | ADITYA SHUKLA   | ADI SHUKLA     | ADITYA   | M   | adishukla@gmail.com      | 4752257594 |
| CLIENT | ABHI PATEL      | ABHIPATEL      | ABHI     | M   | abhipatel@gmail.com      | 4752257594 |
| CLIENT | KRUTARTH SAILOR | KRUTARTHSAILOR | KRUTARTH | M   | krutarthsailor@gmail.com | 4752257594 |
+--------+-----------------+----------------+----------+-----+--------------------------+------------+*/

/* List of all messages exchanged*/

select (select fname from usermaster where id=a.fromuser) as FromUser, 
(select fname from usermaster where id=a.touser) as Touser,
body  from portalmessage a;

/*+----------+----------+--------------+
| FromUser | Touser   | body         |
+----------+----------+--------------+
| ADITYA   | DHAVAL   | TEST MESSAGE |
| AMAN     | ABHI     | TEST MESSAGE |
| KRUTARTH | AVI      | TEST MESSAGE |
| SUNIL    | KRUTARTH | TEST MESSAGE |
| AVI      | SUNIL    | TEST MESSAGE |
| ABHI     | AMAN     | TEST MESSAGE |
| DHAVAL   | ADITYA   | TEST MESSAGE |
+----------+----------+--------------+*/
